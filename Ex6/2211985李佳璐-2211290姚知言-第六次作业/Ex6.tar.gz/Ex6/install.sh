cd snarkjs-0.1.11
sudo npm install -g
cd ..
cd circom
sudo npm install -g
cd ..
cd mocha
sudo npm install -g
cd ..
npm install