Name: []

## Question 1

In the following code-snippet from `Num2Bits`, it looks like `sum_of_bits`
might be a sum of products of signals, making the subsequent constraint not
rank-1. Explain why `sum_of_bits` is actually a _linear combination_ of
signals.

```
        sum_of_bits += (2 ** i) * bits[i];
```

## Answer 1

`sum_of_bits` 是一个信号的线性组合，因为和里的每一项都由一个定值（二的幂，`2 ** i`）与一个信号（`bits[i]`）乘等构成。在电路限制中，线性组合指的是每项都由定值与信号相乘后相加构成。由于 `2 ** i` 是在编译时定义的幂值，不依赖于信号的值，因此这个和满足线性组合的要求。它没有包含两个信号乘等，故而不是非线性的。

## Question 2

Explain, in your own words, the meaning of the `<==` operator.

## Answer 2

`<==` 运算符在 `circom` 中用于定义两个信号或表达式之间的相等约束。它确保表达式左边和右边在执行时的计算结果相等。这个运算符不会为左边的信号赋值；而是创建一个约束，需要在电路验证中满足才能被认为有效。

这与 `<--` 运算符有所不同，`<--` 用于为信号赋值，但不创建任何约束。

## Question 3

Suppose you're reading a `circom` program and you see the following:

```
    signal input a;
    signal input b;
    signal input c;
    (a & 1) * b === c;
```

Explain why this is invalid.

## Answer 3

这个约束是无效的，因为 '&' 操作符是按位与运算，它是位运算，而在 circom 中，电路约束必须使用算术运算，即加法和乘法等线性操作才可以用来建立约束。因此，位运算（如'&'）不能直接在 circom 电路中使用。

为了使这个约束有效，可以使用适当的算术操作来代替位运算:

```
(a % 2) * b === c;
```

在 circom 中，a % 2 是可以用来代替 a & 1 的，因为它们在判断奇偶性时的结果是相同的。

这行代码通过将 a 除以 2 后的余数来模拟按位与操作，这样就变成了一个有效的算术约束，适合在 circom 中使用。

